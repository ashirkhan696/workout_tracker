module.exports = {
    database: 'mongodb+srv://syedfaizali145:faizali12345@cluster0.jbpyook.mongodb.net/workout_tracker?retryWrites=true&w=majority',
  };
  